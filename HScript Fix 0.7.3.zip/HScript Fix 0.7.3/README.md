SO uhhh... basically.....

0.7.3 has this weird thing with 'Teacall'

inside source/psychlua you can find HScript.hx which i forget the line but if you do ctrl + F to search you can find 'teacall'

you could manually change 'teacall' to just 'tea' or you can just drag and drop the Hscript.hx in this file into your source/psychlua folder

this info IS on the psych github buuuuuuut it would be easier if someone would just upload the file, so I did, you're welcome...


follow twitter @Squibby06

add my discord

k thx bye